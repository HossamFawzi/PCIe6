//============================================================
// Testbench: tb_poisoned_tlp_handler
// Verifies: Clean pass-through, poisoned detection & drop,
//           AER severity encoding
//============================================================
`timescale 1ns / 1ps

module tb_poisoned_tlp_handler;

    reg          clk, rst_n;
    reg          tlp_ep_bit;
    reg  [4:0]   tlp_type;
    reg          tlp_ok;
    reg  [1023:0] tlp_rx;

    wire         poisoned_detected;
    wire         poison_drop;
    wire [2:0]   poison_to_aer;
    wire         tlp_fwd_valid;

    poisoned_tlp_handler dut (
        .clk(clk), .rst_n(rst_n),
        .tlp_ep_bit(tlp_ep_bit), .tlp_type(tlp_type),
        .tlp_ok(tlp_ok), .tlp_rx(tlp_rx),
        .poisoned_detected(poisoned_detected),
        .poison_drop(poison_drop),
        .poison_to_aer(poison_to_aer),
        .tlp_fwd_valid(tlp_fwd_valid)
    );

    initial clk = 0;
    always #2 clk = ~clk;

    integer pass_count, fail_count;

    initial begin
        $display("========================================");
        $display("  TB: Poisoned TLP Handler");
        $display("========================================");

        pass_count = 0; fail_count = 0;
        rst_n = 0; tlp_ep_bit = 0; tlp_type = 0;
        tlp_ok = 0; tlp_rx = 0;
        #20; rst_n = 1; #10;

        // Test 1: Clean MRd - should forward
        $display("\nTest 1: Clean MRd (EP=0)");
        tlp_ep_bit = 0; tlp_type = 5'b00000; tlp_ok = 1;
        tlp_rx = 1024'hDEAD;
        @(posedge clk); #1;
        tlp_ok = 0;
        @(posedge clk); #1;
        if (tlp_fwd_valid && !poisoned_detected && !poison_drop) begin
            $display("  PASS"); pass_count = pass_count + 1;
        end else begin
            $display("  FAIL"); fail_count = fail_count + 1;
        end

        // Test 2: Poisoned MWr - should drop
        #4;
        $display("\nTest 2: Poisoned MWr (EP=1)");
        tlp_ep_bit = 1; tlp_type = 5'b00000; tlp_ok = 1;
        @(posedge clk); #1;
        tlp_ok = 0;
        @(posedge clk); #1;
        if (!tlp_fwd_valid && poisoned_detected && poison_drop) begin
            $display("  PASS"); pass_count = pass_count + 1;
        end else begin
            $display("  FAIL"); fail_count = fail_count + 1;
        end

        // Test 3: Poisoned Completion - non-fatal AER
        #4;
        $display("\nTest 3: Poisoned CplD (EP=1)");
        tlp_ep_bit = 1; tlp_type = 5'b01010; tlp_ok = 1;
        @(posedge clk); #1;
        tlp_ok = 0;
        @(posedge clk); #1;
        if (poisoned_detected && poison_to_aer == 3'b010) begin
            $display("  PASS: AER=non-fatal"); pass_count = pass_count + 1;
        end else begin
            $display("  FAIL: AER=%b", poison_to_aer); fail_count = fail_count + 1;
        end

        // Test 4: Malformed TLP (tlp_ok=0) - should not forward
        #4;
        $display("\nTest 4: Malformed (tlp_ok=0, EP=0)");
        tlp_ep_bit = 0; tlp_type = 5'b00000; tlp_ok = 0;
        @(posedge clk); #1;
        @(posedge clk); #1;
        if (!tlp_fwd_valid && !poisoned_detected) begin
            $display("  PASS"); pass_count = pass_count + 1;
        end else begin
            $display("  FAIL"); fail_count = fail_count + 1;
        end

        // Test 5: Poisoned Message
        #4;
        $display("\nTest 5: Poisoned Message (EP=1)");
        tlp_ep_bit = 1; tlp_type = 5'b10001; tlp_ok = 1;
        @(posedge clk); #1;
        tlp_ok = 0;
        @(posedge clk); #1;
        if (poisoned_detected && poison_drop && poison_to_aer != 3'b000) begin
            $display("  PASS"); pass_count = pass_count + 1;
        end else begin
            $display("  FAIL"); fail_count = fail_count + 1;
        end

        #20;
        $display("\n========================================");
        $display("  Results: %0d PASSED, %0d FAILED", pass_count, fail_count);
        $display("========================================");
        $finish;
    end

endmodule
