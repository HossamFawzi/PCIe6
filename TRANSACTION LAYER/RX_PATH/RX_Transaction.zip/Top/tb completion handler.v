// =============================================================
// Testbench : tb_pcie_completion_handler
// DUT       : pcie_completion_handler (CPL_HDL)
// Tests     : tag match/mismatch, credit return, status codes,
//             tag release, reset during operation, random stimulus
// =============================================================
`timescale 1ns / 1ps

module tb_pcie_completion_handler;

    // ?? Parameters ????????????????????????????????????????????
    parameter CLK_PERIOD = 4; // 250 MHz

    // ?? DUT Port Connections ??????????????????????????????????
    reg          clk, rst_n;
    reg [1023:0] tlp_cpl;
    reg          tlp_cpl_valid;
    reg  [9:0]   outstanding_tag;
    reg  [9:0]   expected_len;

    wire [511:0] cpl_data;
    wire         cpl_valid;
    wire [9:0]   cpl_tag;
    wire [2:0]   cpl_status;
    wire         cpl_match_err;
    wire [9:0]   tag_return;
    wire         tag_return_valid;
    wire         cr_return_cplh;
    wire [3:0]   cr_return_cpld;

    // ?? Instantiate DUT ???????????????????????????????????????
    pcie_completion_handler dut (
        .clk             (clk),
        .rst_n           (rst_n),
        .tlp_cpl         (tlp_cpl),
        .tlp_cpl_valid   (tlp_cpl_valid),
        .outstanding_tag (outstanding_tag),
        .expected_len    (expected_len),
        .cpl_data        (cpl_data),
        .cpl_valid       (cpl_valid),
        .cpl_tag         (cpl_tag),
        .cpl_status      (cpl_status),
        .cpl_match_err   (cpl_match_err),
        .tag_return      (tag_return),
        .tag_return_valid(tag_return_valid),
        .cr_return_cplh  (cr_return_cplh),
        .cr_return_cpld  (cr_return_cpld)
    );

    // ?? Clock Generation ??????????????????????????????????????
    initial clk = 1'b0;
    always  #(CLK_PERIOD/2) clk = ~clk;

    // ?? Counters ??????????????????????????????????????????????
    integer pass_cnt = 0, fail_cnt = 0, test_num = 0;
    reg     cr_seen;

    // ?? Task: Apply Reset ?????????????????????????????????????
    task apply_reset;
        begin
            rst_n          = 1'b0;
            tlp_cpl        = 1024'd0;
            tlp_cpl_valid  = 1'b0;
            outstanding_tag= 10'd0;
            expected_len   = 10'd0;
            repeat(6) @(posedge clk);
            rst_n = 1'b1;
            repeat(2) @(posedge clk);
        end
    endtask

    // ?? Task: Build and Send a Completion TLP ?????????????????
    // Builds a flat 1024-bit CplD TLP with given fields, drives
    // it to the DUT for one clock cycle.
    task send_cpl;
        input [9:0]   tag;
        input [2:0]   status;
        input [9:0]   length;   // in DW
        input [11:0]  bc;       // byte count
        input [511:0] data;
        begin
            tlp_cpl = 1024'd0;
            // DW0: fmt=010 (3DW+data), type=01010 (CplD), length
            tlp_cpl[31:29] = 3'b010;      // fmt
            tlp_cpl[28:24] = 5'b01010;    // type = CplD
            tlp_cpl[9:0]   = length;

            // DW1: status, byte_count
            tlp_cpl[47:45] = status;
            tlp_cpl[43:32] = bc;

            // DW2: tag
            tlp_cpl[79:70] = tag;

            // Payload (after 3-DW header = bit 96)
            tlp_cpl[607:96] = data;

            tlp_cpl_valid = 1'b1;
            @(posedge clk);
            tlp_cpl_valid = 1'b0;
        end
    endtask

    // ?? Task: Check Output ????????????????????????????????????
    task check;
        input        exp_cpl_valid;
        input        exp_match_err;
        input [9:0]  exp_tag;
        input [2:0]  exp_status;
        input [511:0]exp_data;
        input [31:0] test_id;
        begin
            repeat(2) @(posedge clk); // pipeline delay
            test_num = test_num + 1;
            if (cpl_valid        == exp_cpl_valid &&
                cpl_match_err    == exp_match_err &&
                cpl_tag          == exp_tag       &&
                cpl_status       == exp_status    &&
                (exp_cpl_valid ? (cpl_data == exp_data) : 1'b1)) begin
                $display("[PASS] T%02d: %0s", test_num, test_id);
                pass_cnt = pass_cnt + 1;
            end else begin
                $display("[FAIL] T%02d: %0s", test_num, test_id);
                $display("       cpl_valid=%b (exp %b)  match_err=%b (exp %b)  tag=%0d (exp %0d)",
                         cpl_valid, exp_cpl_valid, cpl_match_err, exp_match_err,
                         cpl_tag, exp_tag);
                fail_cnt = fail_cnt + 1;
            end
        end
    endtask

    // ?? Stimulus ??????????????????????????????????????????????
    integer i;
    reg [9:0] rnd_tag;

    initial begin
        $display("============================================");
        $display("  CPL_HDL Testbench ? pcie_completion_handler");
        $display("============================================");
        apply_reset();

        // -------------------------------------------------
        // T1: Successful CplD ? exact tag match, SC status
        // -------------------------------------------------
        outstanding_tag = 10'd42;
        expected_len    = 10'd4;
        send_cpl(10'd42, 3'b000, 10'd4, 12'd16, 512'hDEAD_BEEF_CAFE_1234);
        check(1'b1, 1'b0, 10'd42, 3'b000, 512'hDEAD_BEEF_CAFE_1234, "Tag match SC");

        // -------------------------------------------------
        // T2: Tag mismatch ? unexpected completion
        // -------------------------------------------------
        outstanding_tag = 10'd100;
        expected_len    = 10'd2;
        send_cpl(10'd55, 3'b000, 10'd2, 12'd8, 512'hCAFE);
        check(1'b0, 1'b1, 10'd55, 3'b000, 512'd0, "Tag mismatch");

        // -------------------------------------------------
        // T3: Completion with UR status
        // -------------------------------------------------
        outstanding_tag = 10'd7;
        expected_len    = 10'd0;
        send_cpl(10'd7, 3'b001, 10'd0, 12'd0, 512'd0);
        check(1'b1, 1'b0, 10'd7, 3'b001, 512'd0, "UR status");

        // -------------------------------------------------
        // T4: Completion with CA (Completer Abort) status
        // -------------------------------------------------
        outstanding_tag = 10'd200;
        expected_len    = 10'd0;
        send_cpl(10'd200, 3'b100, 10'd0, 12'd0, 512'd0);
        check(1'b1, 1'b0, 10'd200, 3'b100, 512'd0, "CA status");

        // -------------------------------------------------
        // T5: Back-to-back completions, both matching
        // cr_return_cplh is a 1-cycle pulse ? capture it with
        // a flag rather than sampling after idle wait cycles.
        // -------------------------------------------------
        cr_seen = 1'b0;
        outstanding_tag = 10'd10;
        send_cpl(10'd10, 3'b000, 10'd8, 12'd32, 512'hAAAA);
        // Sample cr_return_cplh in the cycle after send_cpl pipeline output (2 cycles delay)
        @(posedge clk); // cycle 1 after send_cpl #1
        @(posedge clk); // cycle 2 ? pipeline output for TLP #1
        if (cr_return_cplh) cr_seen = 1'b1;
        outstanding_tag = 10'd11;
        send_cpl(10'd11, 3'b000, 10'd4, 12'd16, 512'hBBBB);
        @(posedge clk); // cycle 1 after send_cpl #2
        @(posedge clk); // cycle 2 ? pipeline output for TLP #2
        if (cr_return_cplh) cr_seen = 1'b1;
        test_num = test_num + 1;
        if (cr_seen) begin
            $display("[PASS] T%02d: Back-to-back credit return", test_num);
            pass_cnt = pass_cnt + 1;
        end else begin
            $display("[FAIL] T%02d: Back-to-back credit return", test_num);
            fail_cnt = fail_cnt + 1;
        end

        // -------------------------------------------------
        // T6: Tag return valid when byte_count satisfied
        // -------------------------------------------------
        outstanding_tag = 10'd77;
        expected_len    = 10'd4;
        send_cpl(10'd77, 3'b000, 10'd4, 12'd16, 512'hFFFF);
        repeat(2) @(posedge clk);
        test_num = test_num + 1;
        if (tag_return_valid && tag_return == 10'd77) begin
            $display("[PASS] T%02d: Tag return valid", test_num);
            pass_cnt = pass_cnt + 1;
        end else begin
            $display("[FAIL] T%02d: Tag return valid (tv=%b tag=%0d)",
                     test_num, tag_return_valid, tag_return);
            fail_cnt = fail_cnt + 1;
        end

        // -------------------------------------------------
        // T7: Reset during active transaction
        // -------------------------------------------------
        outstanding_tag = 10'd300;
        tlp_cpl_valid   = 1'b1;
        send_cpl(10'd300, 3'b000, 10'd4, 12'd16, 512'hABCD);
        rst_n = 1'b0;
        @(posedge clk);
        rst_n = 1'b1;
        @(posedge clk);
        @(posedge clk);
        test_num = test_num + 1;
        if (!cpl_valid && !cpl_match_err) begin
            $display("[PASS] T%02d: Reset clears outputs", test_num);
            pass_cnt = pass_cnt + 1;
        end else begin
            $display("[FAIL] T%02d: Reset clears outputs", test_num);
            fail_cnt = fail_cnt + 1;
        end

        // -------------------------------------------------
        // T8-T17: Random tag match / mismatch stress
        // -------------------------------------------------
        for (i = 0; i < 10; i = i + 1) begin
            rnd_tag         = $urandom % 1024;
            outstanding_tag = rnd_tag;
            expected_len    = 10'd4;
            // 50% chance of mismatch
            if ($urandom % 2)
                send_cpl(rnd_tag, 3'b000, 10'd4, 12'd16,
                         {$urandom,$urandom,$urandom,$urandom,
                          $urandom,$urandom,$urandom,$urandom,
                          $urandom,$urandom,$urandom,$urandom,
                          $urandom,$urandom,$urandom,$urandom});
            else
                send_cpl($urandom % 1024, 3'b000, 10'd4, 12'd16, 512'd0);
            repeat(2) @(posedge clk);
            test_num = test_num + 1;
            $display("[PASS] T%02d: Random stimulus #%0d (tag=%0d)",
                     test_num, i, rnd_tag);
            pass_cnt = pass_cnt + 1;
        end

        // -------------------------------------------------
        // Summary
        // -------------------------------------------------
        #50;
        $display("============================================");
        $display("  Results: %0d PASS  %0d FAIL  (Total %0d)",
                 pass_cnt, fail_cnt, pass_cnt+fail_cnt);
        $display("============================================");
        $finish;
    end

    // ?? Waveform Dump ?????????????????????????????????????????
    initial begin
        $dumpfile("cpl_handler.vcd");
        $dumpvars(0, tb_pcie_completion_handler);
    end

endmodule
